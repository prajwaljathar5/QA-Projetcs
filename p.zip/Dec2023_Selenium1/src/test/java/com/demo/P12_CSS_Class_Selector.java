package com.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P12_CSS_Class_Selector {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
	WebDriver driver = new ChromeDriver();
	driver.get("https://rahulshettyacademy.com/locatorspractice/");
	
 // CSS Selector - #id
		driver.findElement(By.cssSelector("#inputUsername")).sendKeys("Deepjoshi");
		
		Thread.sleep(2000);
		
// CSS Selector - element
	String title =	driver.findElement(By.cssSelector("h1")).getText();
	System.out.println(title);
	
	Thread.sleep(1000);
	
// CSS Selector - attribute
	driver.findElement(By.cssSelector("input[type='password']")).sendKeys("Deep@123");
	
	
// CSS Selector - .Class
		driver.findElement(By.cssSelector(".submit")).click();
		
		
		Thread.sleep(3000);
		  
		driver.quit();
   
		
		
	
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

