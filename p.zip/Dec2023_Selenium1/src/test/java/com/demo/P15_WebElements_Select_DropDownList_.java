package com.demo;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P15_WebElements_Select_DropDownList_ {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/14.WebElements.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	

// Select - Option
	
	public static void SelectOption() throws InterruptedException { 
	Thread.sleep(1000);
	
	WebElement SelectElement = driver.findElement(By.name("player"));
	
	
// ***Single Selection*** 		
	
// We Can Do the Selection by 3 Ways :
	
	Select player = new Select(SelectElement);
	
//	player.selectByIndex(2);                   // 1.Using the Index 
	
//	player.selectByValue("vk");                // 2.Using the Value
	
	player.selectByVisibleText("Virat Kohli"); // 3.Using the Visible Text
	Thread.sleep(1000);                        
	
	
	

// How to get information about the Available Options ???????
	
//***We Can Get More Information about the Select-Option.****
	
	
	List<WebElement> options = player.getOptions();
	for ( WebElement e: options ) {
		System.out.println(e.getText());
	}
	
	
	
	
	
	
// ***Multiple Selection*** 	
	
	Select players = new Select(driver.findElement(By.name("Favourite player")));
	
		players.selectByIndex(0);       // Selecting by index
	    players.selectByValue("kl");   // Selecting Second by Value
	    
	    
	    
	    
	}

	public static void main ( String[] args) throws InterruptedException {
	start(); 
	SelectOption();
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

