package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class P05_IDLocatorLocalPage {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
		     WebDriver driver = new FirefoxDriver();
		     
		// Open the Url
			driver.get("https://www.amazon.in/");	  
			driver.manage().window().maximize();
			
		// find the element using id locator
			WebElement e = driver.findElement(By.id("twotabsearchtextbox"));
			
		// Send Some data (text) to the element
			e.sendKeys("Asus Vivobook 15");
			
			  Thread.sleep(3000);
			     
		WebElement search = driver.findElement(By.id("nav-search-submit-button"));
		search.click();
			
		
	     
	    // Close the Browser    
	        driver.quit();
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

