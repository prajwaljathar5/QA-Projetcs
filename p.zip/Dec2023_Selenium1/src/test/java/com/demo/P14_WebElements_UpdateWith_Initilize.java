package com.demo;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class P14_WebElements_UpdateWith_Initilize {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/14.WebElements.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	
//radioButtons():
	
	public static void radioButtons() throws InterruptedException { 
	Thread.sleep(1000);
	
	WebElement RadioBtn = driver.findElement(By.id("id_mi"));
	
	System.out.println("MI is displayed: "+RadioBtn.isDisplayed());
	System.out.println("MI is Enabled: "+RadioBtn.isEnabled());
	System.out.println("MI is Selected: "+RadioBtn.isSelected());
	
	RadioBtn.click();
	System.out.println("MI is Selected(after click): "+RadioBtn.isSelected());
	
	Thread.sleep(1000);
	
	
}
	
	
//CheckBoxes() :	
	
	public static void checkBoxes() throws InterruptedException {
	
	Thread.sleep(1000);
	
	WebElement Checkbox = driver.findElement(By.id("id_coconut"));
	Checkbox.click();
	
	Thread.sleep(1000);
	
	Checkbox = driver.findElement(By.id("id_mango"));
	Checkbox.click();
	
	Thread.sleep(1000);
	
	
}
//register():
	
	public static void register() throws InterruptedException {
	
	driver.findElement(By.tagName("button")).click();
	
}	
	
	public static void main ( String[] args) throws InterruptedException {
	start(); 
	radioButtons();
    checkBoxes(); 
    register();
    stop();
    
    
    
    
}
}
	
	
	
	
	
	
	

	
	
	

