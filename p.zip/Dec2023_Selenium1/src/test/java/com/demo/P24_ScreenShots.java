package com.demo;
import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class P24_ScreenShots {

	public static void main(String[] args) throws InterruptedException, IOException {

		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		Thread.sleep(2000);

		WebElement e = driver.findElement(By.id("APjFqb"));
		e.sendKeys("India vs England score");
		e.sendKeys(Keys.ENTER);
		
		Thread.sleep(1000);
		
		// Let's take a screenshot
		TakesScreenshot ss = (TakesScreenshot) driver;
		File f = ss.getScreenshotAs(OutputType.FILE);
		// Save the file object into a destination file
		File dest = new File("my_ss.png");
		FileUtils.copyFile(f, dest);
		System.out.println("Screenshot taken...");
		
		Thread.sleep(3000);

		driver.quit();

	}

}





		
		
		
		  
	
		
		
	
    
	    
	     
	
	
	
	
	

	
	
	

	
	
	

