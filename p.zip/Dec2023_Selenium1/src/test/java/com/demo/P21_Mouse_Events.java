package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


public class P21_Mouse_Events {
	
	


	
/*Mouse Events:-
	@Click
	@Hover
	@Context Click (right click)
	@Double Click
	@Drag and Dro...
	
To use mouse events, Selenium provides us with a special class known as “Actions”
**Steps to use the Actions class..
1.Create an object of the Actions class (pass the driver to the constructor)
2.Build the action
3.Perform the action
*/

//@hover Code:-	
 public static void Hover() throws InterruptedException {
	 WebDriver driver = new FirefoxDriver();
	 Thread.sleep(1000);
	
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	
	WebElement Signin= driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
	
// Step 1:- Create Object of Action Class
	Actions actions = new Actions(driver);

// Step 2:-	Build the Actions
	Action action = actions.moveToElement(Signin).build();
	
// Step 3:- Perform the Action
	action.perform();
	
	Thread.sleep(4000);
	driver.quit();

	}
//@ContextClick Code:-	
 public static void ContextClick() throws InterruptedException {	
	WebDriver driver = new FirefoxDriver();
	driver.get("https://swisnl.github.io/jQuery-contextMenu/demo.html");
	driver.manage().window().maximize();
	
	Thread.sleep(2000);
	
WebElement button =	driver.findElement(By.xpath("/html/body/div/section/div/div/div/p/span"));
	 
// Right Click on the Button:
   Actions action = new Actions(driver);
   action.contextClick(button).perform();
   Thread.sleep(1000);
   
// Select "Copy" From Menu :-
   driver.findElement(By.xpath("/html/body/ul/li[3]")).click();
   Thread.sleep(1000);

   driver.quit();
	 
	 
 }	 

//@DoubleClick Code:-	 
 
 public static void doubleclick() throws InterruptedException {	
	WebDriver driver = new FirefoxDriver();
	driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_ondblclick");
	driver.manage().window().maximize();
	
	Thread.sleep(2000);
	
// Since the paragraph we are trying to locate is inside a frame
// Let's first switch to that frame
	driver.switchTo().frame("iframeResult");
	
// Locate the element	
	WebElement para = driver.findElement(By.xpath("/html[1]/body[1]/p[1]"));
	
//Perform the double click action	
	Actions action = new Actions(driver);
	action.doubleClick(para).perform();
	
	Thread.sleep(2000);
	driver.quit();
	
	
	 
	
	
 }
//Drag & Drop Code:- 
 public static void dragAndDrop() throws InterruptedException {
		Thread.sleep(2500);
		
		WebDriver driver = new FirefoxDriver();
		driver.get("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html");
		driver.manage().window().maximize();
		Thread.sleep(2500);
		
// Step 1: Find the source element 		
		WebElement source = driver.findElement(By.id("box3"));
		
// Step 2: Find the target element
		WebElement target = driver.findElement(By.id("box103"));
		
// Step 3: Perform the drag and drop
		Actions actions = new Actions(driver);		
		actions.dragAndDrop(source, target).perform();
		
        Thread.sleep(3500);
		
		driver.quit();
		
 }		
	
//MAIN METHOD() :
	
	public static void main ( String[] args) throws InterruptedException {
	
	
//	Hover();
	
//  ContextClick();
		
//  doubleclick();
    
   dragAndDrop(); 
    
}
}

	
	
	
	
	
	

	
	
	

