package com.demo;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class P23_Xpath_Locator_PartialXpath_RelativePath2 {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 

		WebDriver driver = new FirefoxDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
        Thread.sleep(1000);
        
        
        WebElement e = driver.findElement(By.id("twotabsearchtextbox"));
        
        JavascriptExecutor jse = (JavascriptExecutor)driver;
        jse.executeScript("arguments[0].setAttribute('value','One plus nord');", e);
		
		
		Thread.sleep(3000);

		driver.quit();


		
 
		
		

		
		
		
		driver.quit();
		
		
		
		
		
		
		  
	
		
		
	
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

