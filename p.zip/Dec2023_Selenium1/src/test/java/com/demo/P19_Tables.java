package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P19_Tables {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/19.Tables.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	

//Table :
	
	
	public static void Tables() throws InterruptedException {
		Thread.sleep(1000);
//Virat			
	String td1 = driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]")).getText();		
	System.out.println(td1);

//Matches Played:
	String mp1 = driver.findElement(By.xpath("//table/tbody/tr[1]/td[3]")).getText();		
	System.out.println(mp1);	
	int matches1 = Integer.parseInt(mp1);
	
//Rohit	
	String td2 = driver.findElement(By.xpath("//table/tbody/tr[2]/td[1]")).getText();		
	System.out.println(td2);
//Matches Played:	
	String mp2 = driver.findElement(By.xpath("//table/tbody/tr[2]/td[3]")).getText();		
	System.out.println(mp2);	
	int matches2 = Integer.parseInt(mp2);
	
// Print the total Macthes played by "Virat & Rohit"....
	int total = matches1 + matches2 ;
	System.out.println("Total Of Virat & Rohit Matches= "  + total );
		
	Thread.sleep(1000);
	}

//In the above example, we are handling the data in a static way. (fixed data)	
//In real projects/scenarios, the tables are mostly dynamic. 
// (means the data can increase/decrease)..
//If we observe the *** index ***is the only thing that we need to change (for above example).
	

// SO LETS WRITE THE SAME CODE dynamically :-
	
	public static void dynamicTable2()throws InterruptedException {
	
		for (int i=1 ; i<=2 ; i++) {
		String data = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[1]")).getText();
		System.out.println(data);
		
		String mp = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]")).getText();
		System.out.println(">>"+mp);
	}
}

// SO LETS READ THE DATA FOR ALL PLAYRES :-	
	
	public static void dynamicTable6()throws InterruptedException {
		
		int total= 0;
			
		for (int i=1 ; i<=6 ; i++) {
				
		String data = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[1]")).getText();
		System.out.println(data);
			
		String mp = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]")).getText();
		System.out.println(">>"+mp);
			
		total = total + Integer.parseInt(mp);
			
			}	
	
		System.out.println("TOTAL NUMBER OF MATCHES: "+total);
}
	
 
//	In the above example, we still have the loop condition as “<= 6”... 
//	which is not really dynamic ,So let’s make it fully dynamic:
	
	
	
// SO MAKE IT REAL dyanmic :-	
	
		public static void RealdynamicTable()throws InterruptedException {
			
// step 1: calculate number of rows:-			
			List<WebElement> rows = driver.findElements(By.xpath("//table/tbody/tr"));
			System.out.println("Count: " + rows.size());
			
//step 2: Find data for each rows:-			
			int total= 0;	
			for (int i=1 ; i<=rows.size() ; i++) {
					
			String data = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[1]")).getText();
			System.out.println(data);
				
			String mp = driver.findElement(By.xpath("//table/tbody/tr[" + i + "]/td[3]")).getText();
			System.out.println(">>"+mp);
				
			total = total + Integer.parseInt(mp);
				
				}	
		
			System.out.println("TOTAL NUMBER OF MATCHES: "+total);
	}	
	
	
	
//Main Method() :
	
	public static void main ( String[] args) throws InterruptedException {
	start(); 
	
	Tables();
	
	dynamicTable2();
	
	dynamicTable6();
	
	RealdynamicTable();
	
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

