package com.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HelloSelenium {

	public static void main(String[] args) {
		
	//  WebDriver	driver = new EdgeDriver();
		WebDriver driver = new FirefoxDriver();
		
		driver.get("https://www.flipkart.com/");
		
		
    
        
        
        
 //Dec 29, 2023 11:48:18 PM org.openqa.selenium.devtools.CdpVersionFinder findNearestMatch
 // WARNING: Unable to find an exact match for CDP version 120, returning the closest version; found: 119; Please update to a Selenium version that supports CDP version 120
      
	}

}
