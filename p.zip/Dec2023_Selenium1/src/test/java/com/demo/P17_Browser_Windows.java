package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P17_Browser_Windows {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/15.Windows-Main.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	

	
	public static void BrowserWindows() throws InterruptedException {
		
		String handle1, handle2, handle3;
		
// To get Current Window Handle.
		String handle = driver.getWindowHandle();
		System.out.println("Window handle1: "+handle);
		
		Thread.sleep(2000);
		
// Click on the link (to open another Window)
	driver.findElement(By.linkText("Go to DashBoard")).click();
	
/*the below code will give us the main windows handle only
 * it will not give the handle of the second window 
 * for that we will have to switch to that window */
	
//	String handle2 = driver.getWindowHandle();
//  System.out.println("Window handle2: "+handle2);
	
	Set<String> handles = driver.getWindowHandles();
	System.out.println("Printing all Handles");
	for (String s : handles) {
		System.out.println(">>"+s);
		
		Thread.sleep(2000);
}
	System.out.println("Printing all handles - Iterating  over Set");
	Iterator<String> a = handles.iterator();
//	while(a.hasNext()) {
//		System.out.println(">>"+a.next());
	
	 handle1 = a.next();  // main Window handle
	 handle2 = a.next();  // Dashboard Window Handle

// Lets Switch to second Window (Dashboard)	
	driver.switchTo().window(handle2);
	
	Thread.sleep(2000);
	driver.findElement(By.linkText("See My Profile")).click();
	Thread.sleep(2000);
	
//Now Lets get all the handles again
	handles = driver.getWindowHandles();
	a = handles.iterator();
	handle1 = a.next();
	handle2 = a.next();
	handle3 = a.next();

// we have all 3 handles now , Lets Switch between them.
	driver.switchTo().window(handle1);
	Thread.sleep(2000);
	driver.switchTo().window(handle2);
	Thread.sleep(2000);
	driver.switchTo().window(handle3);
	
	
	}
	

	
	

	public static void main ( String[] args) throws InterruptedException {
	start(); 
	
	BrowserWindows();
	
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

