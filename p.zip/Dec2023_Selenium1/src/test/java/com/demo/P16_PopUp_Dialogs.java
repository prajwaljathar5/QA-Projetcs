package com.demo;


import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P16_PopUp_Dialogs {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/14.WebElements.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	

// Pop-Ups
	
	//**ALERT**//
	public static void AlertBox() throws InterruptedException { 
	Thread.sleep(1000);
	
	driver.findElement(By.id("id_alert")).click();
	Thread.sleep(1000);
	
// Switch to the Alert :
	
	Alert e = driver.switchTo().alert();
	
	e.accept();    // accept the alert (Clicked "OK")
	Thread.sleep(1000);
}
	
	//**CONFIRM**//
	public static void ConfirmBox() throws InterruptedException {
		
		driver.findElement(By.id("id_confirm")).click();
		Thread.sleep(1000);
		
// Switch to the Alert :		
        
		Alert e = driver.switchTo().alert();
		
		e.dismiss();        // dismiss the alert (Clicked "cancel")
		
}

	//**prompt**//
	
	public static void displayPrompt() throws InterruptedException {
		
		driver.findElement(By.id("id_prompt")).click();
		Thread.sleep(1000);
		
// Switch to the Alert :		
		
       Alert e = driver.switchTo().alert();
       Thread.sleep(1000);
       e.sendKeys("ShreeRam");  // Pass Some Data
       e.accept();              // Accept the alert (Clicked "ok")
       
     
	}

	
	
	
	
	
	public static void main ( String[] args) throws InterruptedException {
	start(); 
	AlertBox();
	ConfirmBox();
	displayPrompt();
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

