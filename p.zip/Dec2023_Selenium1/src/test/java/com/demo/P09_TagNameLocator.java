package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P09_TagNameLocator {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Local Page 08
		driver.get("http://127.0.0.1:5500/08.Links.html");	  
		driver.manage().window().maximize();
		 
		Thread.sleep(3000);
	// Search anchor Html Element	 
	//	driver.findElement(By.tagName("a")).click();
		
	// 	 Search Button Html Element	 
	//	driver.findElement(By.tagName("button")).click();
		
	//	Search Input Html Element	 
		driver.findElement(By.tagName("input")).sendKeys("Rohit Sharma");
		
		Thread.sleep(3000);
		  
		  driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

