package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;


public class P22_KeyBoardEvents {

	
	public static void main ( String[] args) throws InterruptedException {
		WebDriver driver = new FirefoxDriver();
		driver.get("https://text-compare.com/");
		driver.manage().window().maximize();
		Thread.sleep(2500);

		
		driver.findElement(By.id("inputText1")).sendKeys("Selenium");
        Actions actions = new Actions(driver);
        
// SELECT ALL TEXT: Ctrl + a        
       actions.keyDown(Keys.CONTROL);
       actions.sendKeys("a");
       actions.keyUp(Keys.CONTROL);
       actions.perform();
       
// COPY text: Ctrl + c      
      actions.keyDown(Keys.CONTROL);     
      actions.sendKeys("c");
      actions.keyDown(Keys.CONTROL);     
      actions.perform();     
      Thread.sleep(1500);
		
// Press tab
		actions.sendKeys(Keys.TAB);
		actions.perform();
		
		Thread.sleep(1500);
		
// PASTE text: Ctrl + v
		actions.keyDown(Keys.CONTROL).sendKeys("v").keyUp(Keys.CONTROL).perform();
		
		Thread.sleep(1500);
		
// Click "Compare" button
		driver.findElement(By.xpath("//*[@id=\"compareButton\"]")).click();
		
		Thread.sleep(2000);
		
// Print the result
		String msg = driver.findElement(By.xpath("/html/body/div[2]/span")).getText();
		System.out.println("Message: " + msg);
		
		Thread.sleep(3500);

		driver.quit();

	}


       
}


	
	
	
	
	
	

	
	
	

