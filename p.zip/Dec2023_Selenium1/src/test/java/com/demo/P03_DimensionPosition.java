package com.demo;

import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class P03_DimensionPosition {


public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
	// ChromeDriver - Used for Google Chrome Browser
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Url
		driver.get("https://www.flipkart.com/");	  
		
	// Get the Window Position
        Point Pos = driver.manage().window().getPosition();
        System.out.println(" pos X = "+ Pos.getX());
        System.out.println(" pos Y = "+ Pos.getY());
		
	// 2 Second Delay
        Thread.sleep(2000);
     
    // Set the Window Position
        Point newPos  = new Point(100, 180);
        driver.manage().window().setPosition(newPos);
        
    // Close the Browser    
        driver.quit();
    
     
		
}

}
