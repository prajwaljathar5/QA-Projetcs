package com.demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P11_findElement_vs_findElementS {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://rahulshettyacademy.com/locatorspractice/");
		driver.manage().window().maximize();
		
	// "Implicit Wait" is Known as Global Wait.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
	// Step 1:Provide Username and Password	
		driver.findElement(By.id("inputUsername")).sendKeys("Admin");  // Invalid Username
		driver.findElement(By.name("inputPassword")).sendKeys("Admin123");  // Invalid Username
		
		Thread.sleep(3000);
		
	// Step 2:Click On the Login Button
		driver.findElement(By.className("submit")).click();		
		
	// Step 3:Read the Error Message and Displayed it On Console.
		String errorMsg = driver.findElement(By.className("error")).getText();
		System.out.println("Error Message: "+ errorMsg);
	
		Thread.sleep(3000);
		  
		driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

