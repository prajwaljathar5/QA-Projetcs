package com.demo;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;


public class P13_Xpath_Locator_FullXpath_ExactPath_AbsolutePath {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 

		WebDriver driver = new FirefoxDriver();
		driver.get("http://127.0.0.1:5500/X-path.html");
		driver.manage().window().maximize();

//  We Can Specify the Xpath in two Ways :
		
//	1:	" Xpath / Absolute Path / Exact Path " 
		
		driver.findElement(By.xpath("/html[1]/body[1]/form[1]/input[1]")).sendKeys("Morya"); //Username
		
		Thread.sleep(1000);  
		
		driver.findElement(By.xpath("/html[1]/body[1]/form[1]/input[2]")).sendKeys("Morya123"); //Password
		Thread.sleep(1000);
		 
		driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/section[1]/div[1]/input[1]")).sendKeys("Ganpati Bappaa Morya");
		Thread.sleep(1000);
		
		driver.findElement(By.xpath("/html[1]/body[1]/form[1]/input[3]")).click();		
		
//	2:	" Partial-Xpath / Relative Path " 
		
		
		
		driver.quit();
		
		
		
		
		
		
		  
	
		
		
	
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

