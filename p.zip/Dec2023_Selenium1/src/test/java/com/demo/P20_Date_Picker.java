package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P20_Date_Picker {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/20.Date_Picker.html");
	driver.manage().window().maximize();
	}
	
//stop():
	public static void stop() throws InterruptedException {
		driver.quit();
}
	
//Date Picker:-
	
	public static void DatePicker() throws InterruptedException {
	Thread.sleep(1000);
	
//Date format for chrome/Edge Browser:- dd/mm/yyyy	
	
	driver.findElement(By.id("doj")).sendKeys("02-05-2024");	
		
		
//Date format for Firefox Browser:- yyyy/mm/dd			
//	driver.findElement(By.id("doj")).sendKeys("2024-05-02");
	}
	
	
	
	
//Main Method() :
	
	public static void main ( String[] args) throws InterruptedException {
	start(); 
	
	DatePicker();
	
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

