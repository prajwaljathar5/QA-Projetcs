package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P07_LinkTextLocator {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Local Page 08
		driver.get("http://127.0.0.1:5500/08.Links.html");	  
		driver.manage().window().maximize();
		
		driver.findElement(By.linkText("Visit Amazon")).click();
		
	//	driver.findElement(By.linkText("visit amazon")).click();
	//  Note: linkText() is case sensitive. The above line will not Work
			
		  Thread.sleep(3000);
		
	
		  Thread.sleep(3000);
		  
		 
 
          driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

