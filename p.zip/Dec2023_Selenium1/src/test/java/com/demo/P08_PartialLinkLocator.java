package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P08_PartialLinkLocator {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Local Page 08
		driver.get("http://127.0.0.1:5500/08.Links.html");	  
		driver.manage().window().maximize();
		 
		Thread.sleep(3000);
		 
		driver.findElement(By.partialLinkText("Visit Amazon")).click();
		Thread.sleep(3000);
		driver.navigate().back();      // Go back to the Main Page
		
		driver.findElement(By.partialLinkText("Check Score")).click();
		Thread.sleep(3000);
		driver.navigate().back();      // Go back to the Main Page
		
     	driver.findElement(By.partialLinkText("Check live Score")).click();
     	Thread.sleep(3000);
		driver.navigate().back();      // Go back to the Main Page
		
		Thread.sleep(3000);
		  
		  driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

