package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P06_NameLocator {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Url
		driver.get("http://127.0.0.1:5500/03.attributes.html");	  
		driver.manage().window().maximize();
		
		  Thread.sleep(3000);
		
	// Find element using name locator
		
		WebElement username = driver.findElement(By.name("n_username"));
		username.sendKeys("virat");
		
		WebElement password = driver.findElement(By.name("n_password"));
		password.sendKeys("virat@18");
		
		  Thread.sleep(3000);
		  
	// Locate Log in Button
		  
		WebElement logbutton = driver.findElement(By.name("n_log_button"));
		logbutton.click();
	
	
		  Thread.sleep(3000);
 
          driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

