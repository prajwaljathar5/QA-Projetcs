package com.demo;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class P02_WindowsDimensions {

public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
	// ChromeDriver - Used for Google Chrome Browser
	     WebDriver driver = new ChromeDriver();
	     
	// Open the Url
		driver.get("https://www.flipkart.com/");	  
		
	// Get the Window Size	
     Dimension size = driver.manage().window().getSize();
     System.out.println(size.getHeight());
     System.out.println(size.getWidth());
     
     // 2 Second 
     Thread.sleep(2000);
     
     // Set Window Size
     Dimension newsize = new Dimension(800 ,500);
     driver.manage().window().setSize(newsize);     
     
     // 2 Second 
     Thread.sleep(2000);
     
     //close the browser
     driver.quit();
    
     
		
		
		
		
		
        
	}
 
		

	}


