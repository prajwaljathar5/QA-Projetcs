package com.demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P04_IDLocatorAmazon {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		
		     WebDriver driver = new ChromeDriver();
		     
		// Open the Url
			driver.get("https://www.amazon.in/");	  
			driver.manage().window().maximize();
			
		// Find element using id locator
		// "twotabsearchtextbox" ID of search box(Inspect)
			WebElement e = driver.findElement(By.id("twotabsearchtextbox"));
		
		// Send Some Data (text) to the element
			e.sendKeys("Asus Vivobbok 15");
			
			  Thread.sleep(2000);
			  
		// Click on Search 
		// "nav-search-submit-button"	ID of search box(Inspect)
			WebElement search = driver.findElement(By.id("nav-search-submit-button"));
			search.click();
			
		   Thread.sleep(2000);
	     
	    // Close the Browser    
	        driver.quit();
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

