package com.demo;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class P10_Implicit_Explicit_Wait {
	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) 
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://127.0.0.1:5500/09.findElement_vs_findElementS.html");
		driver.manage().window().maximize();
		
	// "Implicit Wait" is Known as Global Wait.
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		List<WebElement> elements = driver.findElements(By.tagName("input"));
		System.out.println("Total input Elements found: "+ elements.size());
		
		elements.get(0).sendKeys("MS");
		elements.get(1).sendKeys("Dhoni");
		elements.get(2).sendKeys("Ranchi");
		
	
	
		Thread.sleep(3000);
		  
		driver.quit();
   
    
	    
	     
	
	
	
	
	
	}
	
	
	
}
	
	
	

