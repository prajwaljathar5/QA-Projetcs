package com.demo;


import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.checkerframework.checker.units.qual.A;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class P18_Frames {
	static WebDriver driver = new FirefoxDriver();
	
//start():
	
	public static void start() throws InterruptedException {  // throws for thread.sleep(2000) 

	driver.get("http://127.0.0.1:5500/18.Frames.html");
	driver.manage().window().maximize();
	}
	
//stop():
	
	public static void stop() throws InterruptedException {
		driver.quit();
}
	

//Frames :
//	When we want to locate any element, 
//  which is inside the page (which is loaded using the frame), then	
//	First we have to switch to that frame...

/* @	Switch to frame can be done in 3 ways:-
	                                       
	                                     1.  Using name/id
	                                     2.  Using index
	                                     3.  Using the WebElement  */

	
	
	public static void Frames1() throws InterruptedException {
		Thread.sleep(2000);
		
//*** 1. Using name/id ***     
		
// Step 1: Switch to the Frame:-
		
//		driver.switchTo().frame("f1");    //*** 1. Using name/id ***
		
//		driver.switchTo().frame(0);       //*** 2. Using index ***
		
		WebElement e = driver.findElement(By.xpath("//iframe[1]"));
		driver.switchTo().frame(e);
		
// Step 2: Find the link & Click it.
		driver.findElement(By.linkText("Go to DashBoard")).click();  
			
		Thread.sleep(2000);
	}

	
	
	
	
	public static void Frames2() throws InterruptedException {
		Thread.sleep(2000);
		
		driver.switchTo().frame("f1");
		driver.findElement(By.linkText("Go to DashBoard")).click();

	    driver.switchTo().defaultContent();               // Switch to Main Page
	    
	    driver.switchTo().frame("f2");
	    driver.findElement(By.id("id_mi")).click();
	    
	    
	    
	}
	
//Main Method() :
	
	public static void main ( String[] args) throws InterruptedException {
	start(); 
	
//	Frames1();
	
	Frames2();
	
    stop();
    
    
    
    
}
}

	
	
	
	
	
	

	
	
	

