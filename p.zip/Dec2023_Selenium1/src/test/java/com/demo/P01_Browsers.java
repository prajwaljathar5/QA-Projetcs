package com.demo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class P01_Browsers {

	public static void main(String[] args) throws InterruptedException {  // throws for thread.sleep(2000) ms
		
		
	//   WebDriver driver = new EdgeDriver();         // EdgeDriver - Used for MicroSoft Edge Browser
	     WebDriver driver = new ChromeDriver();       // ChromeDriver - Used for Google Chrome Browser
		
		driver.get("https://www.flipkart.com/");	  // Open the Url
		
        System.out.println(driver.getCurrentUrl());
        System.out.println(driver.getTitle());
        
        Thread.sleep(2000);                          // 2 Seconds
        
        driver.quit();                               // Close the browser

	}

}
