package Assignment;

public class oracle_Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
