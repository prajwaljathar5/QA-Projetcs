package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Login {
	public static void main(String[] args) throws InterruptedException {

   
		
// STEP 4 : Open the web site...	
		WebDriver driver = new FirefoxDriver();
		driver.get("https://demo.nopcommerce.com/");
		driver.manage().window().maximize();
		
// STEP 5 : Click on the “Log In” link & Fill the Email and Password fields...
	     
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("Tata56@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("Tata@1616");
		driver.findElement(By.className("login-button")).click();
		
		Thread.sleep(3000);
		
// STEP 6 : Click on the “Log out"...		
		driver.findElement(By.className("ico-logout")).click();
		
		driver.quit();
		

	}

}
