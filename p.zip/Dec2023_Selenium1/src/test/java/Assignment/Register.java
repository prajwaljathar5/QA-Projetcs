package Assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Register {
	public static void main(String[] args) throws InterruptedException {
		

// STEP 1: ( Open the web site & Click on the “Register” link )
		 WebDriver driver = new FirefoxDriver();
		 driver.get("https://demo.nopcommerce.com/");
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		 driver.findElement(By.className("ico-register")).click();
		
// STEP 2: Fill in the following fields Using ArrayList:( First name, Last name, Email ,Password & Confirm Password )
		 
		List<WebElement> elements = driver.findElements(By.tagName("input"));
		Thread.sleep(2000);
		elements.get(4).sendKeys("Tata");
		elements.get(5).sendKeys("Harrier");
		elements.get(6).sendKeys("Tata456@gmail.com");
		elements.get(9).sendKeys("Tata@1616");
		elements.get(10).sendKeys("Tata@1616");
		
		Thread.sleep(1000);
		
// STEP 3: ( Click on “Register” Button & You should read this message and print it on the console.!! )
		driver.findElement(By.id("register-button")).click();
		Thread.sleep(3000);
		String Msg = driver.findElement(By.className("result")).getText();
	    System.out.println("Registration Successfull : "+ Msg);
		
	    Thread.sleep(1000);

	 		
// STEP 4 :( Click on the “Log In” link & Fill the Email and Password fields...)
	 	     
	 		driver.findElement(By.className("ico-login")).click();
	 		driver.findElement(By.id("Email")).sendKeys("Tata456@gmail.com");
	 		driver.findElement(By.id("Password")).sendKeys("Tata@1616");
	 		driver.findElement(By.className("login-button")).click();
	 		
	 		Thread.sleep(3000);
	 		
// STEP 5 : ( Click on the “Log out"...)		
	 		driver.findElement(By.className("ico-logout")).click();
	 		
	 		driver.quit();
	 		
		
		
		
	}

}
