package Project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class locked_outuser {
	
		WebDriver driver = null;
		 
		 @BeforeMethod
		public void setup() {
			driver = new  FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get("https://www.saucedemo.com/");
		 }
		 
		 @Test 
		 public void Login() throws InterruptedException {
			  
			driver.findElement(By.name("user-name")).sendKeys("locked_out_user");
		    driver.findElement(By.name("password")).sendKeys("secret_sauce");
			Thread.sleep(2000);
			driver.findElement(By.name("login-button")).click();
			 
			// to Get the Error Title 
			String title = driver.findElement(By.xpath("//*[@id=\"login_button_container\"]/div/form/div[3]/h3")).getText();
			System.out.println(title);
		 }	   

		 @AfterMethod
		 public void teardown () {
			 driver.quit();
		 }
	}

