package Project;

	import java.time.Duration;

	import org.openqa.selenium.By;
	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.testng.annotations.AfterMethod;
	import org.testng.annotations.BeforeMethod;
	import org.testng.annotations.Test;

	public class problem_user {
		WebDriver driver = null;
		 
		 @BeforeMethod
		public void setup() {
			driver = new  ChromeDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			driver.get("https://www.saucedemo.com/");
		 }
		 @Test 
		 public void Login() throws InterruptedException {
			  
			driver.findElement(By.name("user-name")).sendKeys("problem_user");
		    driver.findElement(By.name("password")).sendKeys("secret_sauce");
			Thread.sleep(2000);
			driver.findElement(By.name("login-button")).click();
			
			 // Add To Cart 
		     driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		     driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
		     driver.findElement(By.id("checkout")).click();
		     Thread.sleep(2000);
		     
		     //Checkout: Information
		     driver.findElement(By.id("first-name")).sendKeys("deep");
			 driver.findElement(By.id("last-name")).sendKeys("joshi");
			 driver.findElement(By.id("postal-code")).sendKeys("415002");
			 driver.findElement(By.id("continue")).click();
			 Thread.sleep(2000);
			 
			 // Get the title
			 String title = driver.findElement(By.xpath("//*[@id=\"checkout_info_container\"]/div/form/div[1]/div[4]/h3")).getText();
			 System.out.println(title);
			 Thread.sleep(2000);
	}
		 @AfterMethod
		      public void tearDown () {
			  driver.quit();
		 }
	}

