package Project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.internal.thread.ThreadExecutionException;

	public class standard_user {

		 WebDriver driver = null;
		 
		 @BeforeMethod
		public void setup() {
			driver = new FirefoxDriver();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(100));
			driver.get("https://www.saucedemo.com/");
		}
		 
		 @Test 
		 public void Login() throws InterruptedException {
			
			 driver.findElement(By.name("user-name")).sendKeys("standard_user");
			 driver.findElement(By.name("password")).sendKeys("secret_sauce");
			 driver.findElement(By.name("login-button")).click();
			 Thread.sleep(2000);
		   
			 // Add To Card 
			 
		     driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
		     driver.findElement(By.xpath("//*[@id=\"shopping_cart_container\"]/a")).click();
		     driver.findElement(By.id("checkout")).click();
		     Thread.sleep(2000);
		     
		     //Checkout: Your Information
		     driver.findElement(By.id("first-name")).sendKeys("deep");
			 driver.findElement(By.id("last-name")).sendKeys("joshi");
			 driver.findElement(By.id("postal-code")).sendKeys("415002");
			 driver.findElement(By.id("continue")).click();
			 driver.findElement(By.id("finish")).click();
			 Thread.sleep(2000);
			 
			 // Get title
			 String title = driver.findElement(By.xpath("/html/body/div/div/div/div[2]/h2")).getText();
			 System.out.println(title);
			 Thread.sleep(2000);
		
		 }
		 
		 @AfterMethod
		 public void tearDown () {
			 driver.quit();
		 }
	
}