package Project;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;
import org.testng.internal.thread.ThreadExecutionException;

public class Automation {
	static WebDriver driver = new FirefoxDriver();
    
	@Test (priority = 1)
// Start () :			
// Launch the site:

    public static void start() throws InterruptedException {  
	driver.get("https://www.saucedemo.com/");
	driver.manage().window().maximize();
	
	// "Implicit Wait" is Known as Global Wait.
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	Thread.sleep(2000);
    }
    
    @Test (priority = 3)
// Stop () :	
	  public static void stop() throws InterruptedException {
	  driver.quit();
	  }
    
	@Test (priority = 2) 
// Standard_user () :	  
// Use  “standard_user” and the password mentioned on the site After successful login
	  
	  public static void standards () throws InterruptedException {
		  
	  driver.findElement(By.id("user-name")).sendKeys("standard_user");
	  Thread.sleep(1000);
	  driver.findElement(By.id("password")).sendKeys("secret_sauce");
	  Thread.sleep(1000);
	  driver.findElement(By.id("login-button")).click();
	  Thread.sleep(1000);

// Click on Add to cart and The item will be added to the cart	  
	  driver.findElement(By.id("add-to-cart-sauce-labs-backpack")).click();
	  driver.findElement(By.id("shopping_cart_container")).click();
	  Thread.sleep(2000);
	  
//	Click on the cart to open the cart page and then 
//  Fill the required fields (first name, last name, zip code)


	  
	  driver.findElement(By.id("checkout")).click();   // click on checkout
	  Thread.sleep(2000);
	  driver.findElement(By.id("first-name")).sendKeys("deep");      // first name
	  driver.findElement(By.id("last-name")).sendKeys("joshi");      // last name
	  driver.findElement(By.id("postal-code")).sendKeys("415002");   // zip code
	  driver.findElement(By.id("continue")).click();                  //  Click on continue
	  
	  
	//  It will show the final details. Click on finish.
	  driver.findElement(By.id("finish")).click();                //   Click on finish
	  
	 
	  
           }
	
	
	  public static void main ( String[] args) throws InterruptedException { 
		  start() ;
		  standards();
		  stop();
		  
}
}